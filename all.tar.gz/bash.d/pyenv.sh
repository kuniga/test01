if [ -d "$HOME"/.pyenv/bin ]; then
    PATH=$(_append_path "$PATH" "$HOME"/.pyenv/bin)
    export PATH
    eval "$(pyenv init -)"
#   PYENV_ROOT="$HOME"/.pyenv
#   export PYENV_ROOT
fi
