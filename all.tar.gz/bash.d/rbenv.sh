if [ -d "$HOME"/.rbenv/bin ]; then
    PATH=$(_append_path "$PATH" "$HOME"/.rbenv/bin)
    export PATH
    eval "$(rbenv init -)"
    if ( echo $HOME/usr/lib/libreadline* | grep -q libreadline ); then
        export RUBY_CONFIGURE_OPTS="--with-readline-dir=$HOME/usr"
    fi
fi
